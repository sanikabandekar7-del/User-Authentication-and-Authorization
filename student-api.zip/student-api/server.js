require("dotenv").config();
const express = require("express");
const mysql = require("mysql2/promise");

const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

const app = express();
const PORT = 3000;

// Middleware to read JSON request bodies
app.use(express.json());

// MySQL connection pool
const pool = mysql.createPool({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
  waitForConnections: true,
  connectionLimit: 10
});


const JWT_SECRET = process.env.JWT_SECRET;

// Register a new user
app.post("/api/auth/register", async (req, res) => {
  const { name, email, password } = req.body;

  if (
    typeof name !== "string" ||
    !name.trim() ||
    name.trim().length > 100 ||
    typeof email !== "string" ||
    !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim()) ||
    typeof password !== "string" ||
    password.length < 8 ||
    password.length > 72
  ) {
    return res.status(400).json({
      success: false,
      message: "Provide a valid name, email, and password of 8–72 characters."
    });
  }

  try {
    const hashedPassword = await bcrypt.hash(password, 12);

    const [result] = await pool.execute(
      `INSERT INTO users (name, email, password)
       VALUES (?, ?, ?)`,
      [name.trim(), email.trim().toLowerCase(), hashedPassword]
    );

    res.status(201).json({
      success: true,
      message: "User registered successfully",
      user: {
        id: result.insertId,
        name: name.trim(),
        email: email.trim().toLowerCase(),
        role: "user"
      }
    });
  } catch (error) {
    if (error.code === "ER_DUP_ENTRY") {
      return res.status(409).json({
        success: false,
        message: "An account with this email already exists."
      });
    }

    console.error("Registration error:", error.message);
    res.status(500).json({
      success: false,
      message: "Registration failed"
    });
  }
});

// Login an existing user
app.post("/api/auth/login", async (req, res) => {
  const { email, password } = req.body;

  if (
    typeof email !== "string" ||
    typeof password !== "string" ||
    !email.trim() ||
    !password ||
    password.length > 72
  ) {
    return res.status(400).json({
      success: false,
      message: "Email and password are required."
    });
  }

  try {
    const [users] = await pool.execute(
      "SELECT * FROM users WHERE email = ?",
      [email.trim().toLowerCase()]
    );

    if (users.length === 0) {
      return res.status(401).json({
        success: false,
        message: "Invalid email or password."
      });
    }

    const user = users[0];

    const passwordMatches = await bcrypt.compare(
      password,
      user.password
    );

    if (!passwordMatches) {
      return res.status(401).json({
        success: false,
        message: "Invalid email or password."
      });
    }

    const token = jwt.sign(
      {
        id: user.id,
        email: user.email,
        role: user.role
      },
      JWT_SECRET,
      { expiresIn: "1h" }
    );

    res.status(200).json({
      success: true,
      message: "Login successful",
      token,
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        role: user.role
      }
    });
  } catch (error) {
    console.error("Login error:", error.message);
    res.status(500).json({
      success: false,
      message: "Login failed"
    });
  }
});

// Middleware: verify the login token
function authenticateToken(req, res, next) {
  const authHeader = req.headers.authorization;

  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return res.status(401).json({
      success: false,
      message: "Authentication required. Please log in."
    });
  }

  const token = authHeader.split(" ")[1];

  try {
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch (error) {
    return res.status(401).json({
      success: false,
      message: "Invalid or expired token. Please log in again."
    });
  }
}

// Middleware: check the user's role
function requireRole(role) {
  return (req, res, next) => {
    if (req.user.role !== role) {
      return res.status(403).json({
        success: false,
        message: "You do not have permission to perform this action."
      });
    }

    next();
  };
}



// Helper to validate student IDs
function isValidId(id) {
  return Number.isInteger(Number(id)) && Number(id) > 0;
}

app.use("/api/students", authenticateToken);

// 1. GET: Retrieve all students
app.get("/api/students", async (req, res) => {
  try {
    const [students] = await pool.query(
      "SELECT * FROM students ORDER BY id"
    );

    res.status(200).json({
      success: true,
      data: students
    });
  } catch (error) {
    console.error("Error retrieving students:", error.message);
    res.status(500).json({
      success: false,
      message: "Failed to retrieve students"
    });
  }
});

// 2. GET: Retrieve one student by ID
app.get("/api/students/:id", async (req, res) => {
  if (!isValidId(req.params.id)) {
    return res.status(400).json({
      success: false,
      message: "Invalid student ID"
    });
  }

  try {
    const [students] = await pool.execute(
      "SELECT * FROM students WHERE id = ?",
      [Number(req.params.id)]
    );

    if (students.length === 0) {
      return res.status(404).json({
        success: false,
        message: "Student not found"
      });
    }

    res.status(200).json({
      success: true,
      data: students[0]
    });
  } catch (error) {
    console.error("Error retrieving student:", error.message);
    res.status(500).json({
      success: false,
      message: "Failed to retrieve student"
    });
  }
});

// 3. POST: Add a new student
app.post("/api/students", async (req, res) => {
  const { name, course } = req.body;

  if (
    typeof name !== "string" ||
    !name.trim() ||
    name.trim().length > 100 ||
    typeof course !== "string" ||
    !course.trim() ||
    course.trim().length > 100
  ) {
    return res.status(400).json({
      success: false,
      message: "Valid name and course are required (maximum 100 characters each)"
    });
  }

  try {
    const [result] = await pool.execute(
      "INSERT INTO students (name, course) VALUES (?, ?)",
      [name.trim(), course.trim()]
    );

    const [students] = await pool.execute(
      "SELECT * FROM students WHERE id = ?",
      [result.insertId]
    );

    res.status(201).json({
      success: true,
      message: "Student added successfully",
      data: students[0]
    });
  } catch (error) {
    console.error("Error adding student:", error.message);
    res.status(500).json({
      success: false,
      message: "Failed to add student"
    });
  }
});

// 4. PUT: Update a student
app.put("/api/students/:id", async (req, res) => {
  if (!isValidId(req.params.id)) {
    return res.status(400).json({
      success: false,
      message: "Invalid student ID"
    });
  }

  const { name, course } = req.body;

  if (
    typeof name !== "string" ||
    !name.trim() ||
    name.trim().length > 100 ||
    typeof course !== "string" ||
    !course.trim() ||
    course.trim().length > 100
  ) {
    return res.status(400).json({
      success: false,
      message: "Valid name and course are required (maximum 100 characters each)"
    });
  }

  try {
    const [result] = await pool.execute(
      "UPDATE students SET name = ?, course = ? WHERE id = ?",
      [name.trim(), course.trim(), Number(req.params.id)]
    );

    if (result.affectedRows === 0) {
      const [students] = await pool.execute(
        "SELECT id FROM students WHERE id = ?",
        [Number(req.params.id)]
      );

      if (students.length === 0) {
        return res.status(404).json({
          success: false,
          message: "Student not found"
        });
      }
    }

    const [students] = await pool.execute(
      "SELECT * FROM students WHERE id = ?",
      [Number(req.params.id)]
    );

    res.status(200).json({
      success: true,
      message: "Student updated successfully",
      data: students[0]
    });
  } catch (error) {
    console.error("Error updating student:", error.message);
    res.status(500).json({
      success: false,
      message: "Failed to update student"
    });
  }
});

// 5. DELETE: Remove a student
app.delete("/api/students/:id",requireRole("admin"),async (req, res) => {
  if (!isValidId(req.params.id)) {
    return res.status(400).json({
      success: false,
      message: "Invalid student ID"
    });
  }

  try {
    const [students] = await pool.execute(
      "SELECT * FROM students WHERE id = ?",
      [Number(req.params.id)]
    );

    if (students.length === 0) {
      return res.status(404).json({
        success: false,
        message: "Student not found"
      });
    }

    await pool.execute(
      "DELETE FROM students WHERE id = ?",
      [Number(req.params.id)]
    );

    res.status(200).json({
      success: true,
      message: "Student deleted successfully",
      data: students[0]
    });
  } catch (error) {
    console.error("Error deleting student:", error.message);
    res.status(500).json({
      success: false,
      message: "Failed to delete student"
    });
  }
});

// Verify the database connection before starting the server
async function startServer() {
  try {
    const connection = await pool.getConnection();
    console.log("MySQL database connected successfully!");
    connection.release();

    app.listen(PORT, () => {
      console.log(`Server running at http://localhost:${PORT}`);
    });
  } catch (error) {
    console.error("MySQL connection failed:", error.message);
    console.error("Check that MySQL is running and your credentials are correct.");
    process.exit(1);
  }
}


startServer();
